package com.gentech.erp.hr.repository;

import com.gentech.erp.hr.entity.SanctionLeave;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SanctionLeaveRepository extends JpaRepository<SanctionLeave, Integer> {

}
