package com.gentech.erp.hr.repository;

import com.gentech.erp.hr.entity.BiometricPunchingReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BiometricPunchingReportRepository extends JpaRepository<BiometricPunchingReport, Long> {

}
