package com.gentech.erp.hr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GentechhrapplicationApplication {

    public static void main(String[] args) {
        SpringApplication.run(GentechhrapplicationApplication.class, args);
    }

}
