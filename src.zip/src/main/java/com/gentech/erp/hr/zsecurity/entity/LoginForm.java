package com.gentech.erp.hr.zsecurity.entity;

public record LoginForm(String username, String password) {
}