package com.gentech.erp.hr.repository;

import com.gentech.erp.hr.entity.CompensatoryLeave;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompensatoryLeaveRepository extends JpaRepository<CompensatoryLeave, Integer> {

}