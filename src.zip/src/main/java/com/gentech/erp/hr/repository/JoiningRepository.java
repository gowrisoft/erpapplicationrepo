package com.gentech.erp.hr.repository;

import com.gentech.erp.hr.entity.JoiningReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JoiningRepository extends JpaRepository<JoiningReport, Long> {

}
